# Python：LuffyX 学位入学须知

## 1. 前言：

路飞学城立志帮助有志向的年轻人通过努力学习获得体面的工作和生活！

首先，感谢您的信任并选择了路飞学城，为了能更快的清晰明了学习流程，以下入学须知文档还请您认真阅读。



## 2. 课程购买

(1) 访问路飞学城官网（https://www.luffycity.com），在导航栏中点击 `LuffyX学位`；

(2) 选择您所需LuffyX学位课程：`Python全栈开发（中高级）` 和 `Linux云计算运维（中高级)`，以下以购买**Python全栈开发中级课程**为例，其他课程购买操作与其一致：

![1](https://hcdn1.luffycity.com/data/knight/tutor/1.png)



(3)点击购买后，如果没有登录账号跳转到登录界面，自己如果有账号进行账号密码登录，如果没有会跳转到注册界面，注册账号即可，如下图所示：

![studentManual05](https://hcdn1.luffycity.com/data/knight/tutor/studentManual05.png)

![studentManual06](https://hcdn1.luffycity.com/data/knight/tutor/studentManual06.png)

(4)登录账号点击购买后会跳到如下界面，如果有优惠券进行优先使用优惠券。

![studentManual07](https://hcdn1.luffycity.com/data/knight/tutor/studentManual07.png)

![studentManual08](https://hcdn1.luffycity.com/data/knight/tutor/studentManual08.png)



## 3. 填写报名表

请认真填写报名表，以便根据您的实际情况来匹配导师，进行更有效的学习辅导及日常沟通；
在购买课程结束时，即可填报名表（上图），亦可在订单详情页进入填写报名表页面。

![studentManual09](studentManual09.png)

![studentManual10](https://hcdn1.luffycity.com/data/knight/tutor/studentManual10.png)

![8](https://hcdn1.luffycity.com/data/knight/tutor/8.jpg)



![12](https://hcdn1.luffycity.com/data/knight/tutor/12.png)



绑定微信：点击绑定微信会弹出二维码窗口，进行微信二维码扫描，扫描后会显示已绑定表明绑定成功。

![6](https://hcdn1.luffycity.com/data/knight/tutor/6.jpg)



![7](https://hcdn1.luffycity.com/data/knight/tutor/7.jpg)

![9](https://hcdn1.luffycity.com/data/knight/tutor/9.jpg)



如果您提前关注了路飞学城工作号，您同时也会收到微信通知：

![studentManual43](https://hcdn1.luffycity.com/data/knight/tutor/studentManual43.png)


test


## 4. 享受的权益与服务

### 4.1 服务详情

入学后，我们会根据您的特点为您分配**1对1 的专业技术导师和班主任**，他们将为您服务6个月时间，在这6个月内，导师提供的服务如下：

* 每周至少一次会主动联系您，对学习问题答疑，并对您的学习进度进行督促；
* 学习过程中与本课程有关的技术问题，导师会在工作日最晚8小时内，节假日24小时内给与答复；
* 当您提交作业后，导师会在24小时完成批复，并对作业中遇到的问题及待改进的地方给与指导；
* 每学完一个模块，导师会对您进行不低于20分钟的视频考核。

**导师服务时间安排：**

| **服务**                     | **时间** |
| -------------------------- | ------ |
| **工作日-问题答疑: 9:30 - 21:00** | 8小时内响应 |
| **作业批改**                   | 24小时内  |
| **视频考核**                   | 24小时内  |
| **主动跟进、进度检查**              | 一周1次   |

***节假日另行通知。**



班主任提供的服务如下：

* 对学习进度进行督促；
* 处理休学、复学申请；
* 监督导师服务规范；
* 处理有关课程中的其他事宜。



### 4.2 休学服务

在学位课程6个月学习周期内，您可以申请有且只有一次休学服务，休学时长最长为6个月，且休学过程中不计算学习时间，在休学期间路飞学城将停止提供除课程视频外的所有服务。如果您确认要休学，请主动告知导师和班主任，进行邮件通知。邮件模板请联系班主任，收到邮件后，路飞学城将学习状态改为休学，且会**扣除15000贝里。**

**请注意，6个月学习周期最后一个月不能休学。**



### 4.3 注意事项

* **若在6个月内，您未能完成本课程的学习，我们将不再提供导师服务，未学完的模块也将不能观看，已经开通的模块视频有效期2年。若想继续学习，需找班主任重新续费，重新续费的费用为每个模块500元，包含每个模块3个月的有效期和导师1对1辅导服务。**
* **如果您平均每天保持学习3个小时以上，却未完成本课程的学习，我们也会适当免费延长您的学习周期。**



## 5. 学习方法和方式

### 5.1 学习方法

路飞在“输入+输出+纠正”的科学学习方法的基础上提炼出“ **学、练、改、管、测** ”5个维度，在这5个维度分别进行深耕，以保证教学效果。

![studentManual30](https://hcdn1.luffycity.com/data/knight/tutor/studentManual30.png)





### 5.2 学习方式

LuffyX学位的课程周期大多是5-6个月，具体情况依课程而定，为了缩短学员的成功反馈周期，我们把每个课程都分了多个模块，采取闯关方式学习，即**当前模块必须所有作业及格且通过专业导师的视频考核，即可进入下一模块学习**，就像打游戏闯关一样。本课程共计10个模块，每个模块还分为几个小章节，每个章节都有作业，学员必须把当前模块所有章节的作业都完成后，才能进行闯关考核，考核是1对1(或1个导师同时考核多个在同一模块的学员)视频考核，导师通过提问题、在线让其写代码等方式验证学员是否真正掌握了当前模块的内容，没问题则进入下一模块，有问题则要求其复习后，重新考核，直至闯关成功。

![studentManual31](https://hcdn1.luffycity.com/data/knight/tutor/studentManual31.png)



**推荐的学习方式：**

* 每天花1.5-2小时观看视频（**手机端** https://m.luffycity.com）, 1.5-2小时完成课堂练习及作业；
* 有问题先不要急着到处问，先自己用力想，努力透过现象看问题本质 ，实在想不出来再咨询导师；
* 学习过程中一定要记笔记+多练习，编程是一门实践性学科，光看不练，等于扯蛋，课程笔记我们推荐使用博客园（http://www.cnblogs.com/），各种技术大神都在上面写技术文章，谨记，一定要好好写blog,好的blog会成为您后期找工作的利器，因为很多技术职位都要求应聘者简历上附上blog地址，您写的烂的话，呵呵，自己想去吧。。 。



## 6. 学习入口

### 6.1 如何观看课程视频

在电脑端登录路飞网站官网：https://www.luffycity.com （手机端为：https://m.luffycity.com）, 推荐使用`Google Chrome浏览器`，以下操作以电脑端为示例）并登录您的账号并进行以下操作：

![studentManual15](https://hcdn1.luffycity.com/data/knight/tutor/studentManual15.png)

![studentManual16](https://hcdn1.luffycity.com/data/knight/tutor/studentManual16.png)



### 6.2 如何利用题库测试

对于已购买课程的学员，可以利用路飞学城官网题库进行模块测试和综合能力测试，对知识点进行固定及查缺补漏。

![studentManual17](https://hcdn1.luffycity.com/data/knight/tutor/studentManual17.png)

![studentManual18](https://hcdn1.luffycity.com/data/knight/tutor/studentManual18.png)

![studentManual19](https://hcdn1.luffycity.com/data/knight/tutor/studentManual19.png)

![studentManual20](https://hcdn1.luffycity.com/data/knight/tutor/studentManual20.png)



![studentManual21](https://hcdn1.luffycity.com/data/knight/tutor/studentManual21.png)

![studentManual22](https://hcdn1.luffycity.com/data/knight/tutor/studentManual22.png)

![studentManual23](https://hcdn1.luffycity.com/data/knight/tutor/studentManual23.png)

![studentManual24](https://hcdn1.luffycity.com/data/knight/tutor/studentManual24.png)



### 6.3 如何提学习问题

在日常学习中，遇到课程中的学习问题，推荐以下方式进行提问，以便高效率解决问题：

![studentManual25](https://hcdn1.luffycity.com/data/knight/tutor/studentManual25.png)



正确提问题参考如下：

* 截图，将问题代码截全，不能光抛出报错信息；
* 明示报错信息；
* 明示想要得到的结果或目的；
* 为了解决此问题，自己去查了什么资料，但是却没有解决。



### 6.4 如何提交作业

![studentManual26](https://hcdn1.luffycity.com/data/knight/tutor/studentManual26.png)

![27](https://hcdn1.luffycity.com/data/knight/tutor/27.png)



![studentManual29](https://hcdn1.luffycity.com/data/knight/tutor/studentManual29.png)



### 6.5 如何查看成绩

当导师批改完作业后，您将自动收到成绩微信短信通知，或者您也可前往学习中心查看成绩和导师点评，操作如下：

![studentManual32](https://hcdn1.luffycity.com/data/knight/tutor/studentManual32.png)

![studentManual33](https://hcdn1.luffycity.com/data/knight/tutor/studentManual33.png)

![studentManual34](https://hcdn1.luffycity.com/data/knight/tutor/studentManual34.png)





### 6.6 如何进行考核

**(1) 导师视频考核**

您需要在当前模块所有作业及格后，且准备好了进行模块考核后，主动与导师联系，约定考核时间。建议题库考核成绩每次75分以上，再约导师考核，可以有效提高通过率。

考核形式为QQ视频考核，每个模块的考核时长不低于 20 分钟。

考核内容：

* 自我介绍或总结当前模块所学内容；
* 口述题；
* 编程题。

**注：考核若超过两次（不包含两次），每考一次将扣除1500贝里。**

**(2) 考核通过情况**

考核结束后，导师将对此次考核情况进行总结，并将考核视频上传至路飞管理后台，由路飞学城工作人员进行审核，审核通过后，您将收到开通下一个模块微信通知。



## 7. 如何获得奖学金

### 7.1 奖学金介绍

为鼓励您在官方推荐课程学习周期内，提前完成所有课程学习，我们为本课程特设了奖学金。您报名入学后，路飞学城直接将**所有奖学金（含课程奖学金和作业奖学金）预先放入您的`可挑战奖学金`**。如示例：

![studentManual35](https://hcdn1.luffycity.com/data/knight/tutor/studentManual35.png)





***注：10贝里 = 1RMB**

微信也将收到通知（示例如下）：

![studentManual44](https://hcdn1.luffycity.com/data/knight/tutor/studentManual44.png)





### 7.2 奖学金组成

奖学金包含`课程奖学金`和`作业奖学金`两部分，具体奖励如下：

**(1) 课程奖学金**

课程推荐完成周期 6 个月，在以下时间内完成课程可获取对应的奖学金：

* 3 个月完成所有内容，返还 50000 贝里奖学金
* 4 个月完成所有内容，返还 40000 贝里奖学金
* 5 个月完成所有内容，返还 20000 贝里奖学金
* 6 个月完成所有内容，返还 10000 贝里奖学金

您的奖学金在顺利毕业且拿到 LuffyX 学位证书时即可申请提现，提现流程将在 1 周之内完成。

**(2) 作业奖学金**

导师批改作业后，可以获得如下作业奖学金：

* 作业成绩得A+,获得本次作业全额奖学金，金额根据作业难度不同而定，一般在500-1000贝里之间
* 作业成绩得A, 获得本次作业全额奖学金的80%奖励
* 作业成绩得B+, 获得本次作业全额奖学金的50%奖励
* 作业成绩得分在B+之后，不获得本次作业奖学金奖励
* 未在规定时间内交作业，先扣除奖学金250贝里，再按作业成绩获得本次作业奖学金奖励
* 作业作弊，取消此次所有作业奖学金奖励，并需重新提交作业

作业的奖学金在当前模块通关完成后时，即可申请提现，提现流程在每月月初1-10日内完成。



### 7.3 奖学金计算示例

![studentManual36](https://hcdn1.luffycity.com/data/knight/tutor/studentManual36.jpg)



**(1) 课程奖学金计算方式**

课程奖学金是为鼓励优秀学员提前完成学业而给的奖励，根据提前毕业时间分为4档（如上图所示）。具体示例如下，假设您的课程学习周期为6个月，在2016年10月22日第一次开通课程并进行学习：

a. 如果您在3个月（90天）内顺利毕业且拿到 LuffyX 学位证书，您将获得50000 贝里课程奖学金；

b. 如果您在4个月（120天）内顺利毕业且拿到 LuffyX 学位证书，您将在2017年1月21日收到一条周期惩罚微信通知，扣除10000贝里，最终，您将获得40000 贝里课程奖学金；

c. 如果您在5个月（150天）内顺利毕业且拿到 LuffyX 学位证书，您将在2017年2月21日再收到一条周期惩罚微信通知，扣除20000贝里，最终，您将获得20000 贝里课程奖学金；

d. 如果您在6个月（180天）内顺利毕业且拿到 LuffyX 学位证书，您将在2017年3月21日再收到一条周期惩罚微信通知，扣除10000贝里，最终，您将获得10000 贝里课程奖学金；

e. 如果您在6个月之后，超时毕业或者未完成学业，您将于2017年4月22日再收到一条周期惩罚微信通知，扣除10000贝里，您将不能获得课程奖学金奖励。

**(2) 作业奖学金计算方式**

每次作业奖学金将先从`可挑战奖金`总额中扣除此次作业最高奖学金之后，再加回您应得奖学金奖励，示例如下：

a. 假设此次作业最高奖学金为500贝里，您成绩为A(90分）， 且在作业截止日期之前提交作业，您获得奖学金为400贝里。**系统将先扣除500贝里，再加回400贝里,**计算方式如下：

```
500 * 80% = 400 贝里
```

b. 假设此次作业最高奖学金为500贝里，您成绩为A（90分）， 且在作业截止日期之后提交作业（迟交），您获得奖学金为200贝里，计算方式如下：

```
(500 - 250) * 80% = 200 贝里
```

c. 作业在B+（85分）以下（不含B+）和作弊抄袭，您都将不能获取此次作业奖学金奖励。

***注：奖学金奖惩情况将会通过路飞公众微信号通知**



### 7.4 奖惩详情查询

奖学金奖惩情况将会自动微信通知，同时您也可以通过PC端查看奖惩激励，操作如下：

![studentManual37](https://hcdn1.luffycity.com/data/knight/tutor/studentManual37.png)

![studentManual38](https://hcdn1.luffycity.com/data/knight/tutor/studentManual38.png)





### 7.5 如何提现

当您完成作业或整个学位课程，可以根据以下流程进行提现，提现审核时间为**每月月初的1-10日**进行统一审批：

![studentManual39](https://hcdn1.luffycity.com/data/knight/tutor/studentManual39.png)

![studentManual40](https://hcdn1.luffycity.com/data/knight/tutor/studentManual40.png)

![studentManual41](https://hcdn1.luffycity.com/data/knight/tutor/studentManual41.png)

![studentManual42](https://hcdn1.luffycity.com/data/knight/tutor/studentManual42.png)





## 8. 附录

### 8.1 学习资料

(1)学习资料电脑版网址： http://book.luffycity.com/   账号密码请查看学习专属群公告

浏览器中打开网站会弹出如下界面，表明网页点击成功。

![45](https://hcdn1.luffycity.com/data/knight/tutor/45.png)

(2) 学习资料手机端网址：（ **book.luffycity.com/python-book/index.html** ），

**注意：使用手机端打开网址链接不要直接使用扣扣浏览器打开，要使用手机自带的浏览器打开。**

浏览器中打开网站会弹出如下界面：

![phone04](https://hcdn1.luffycity.com/data/knight/tutor/phone04.png)



### 8.2 手机端观看视频

(1) 有些小伙伴平时学习可能习惯使用手机进行观看视频，手机端学习入口的网址如下所示；

访问路飞官网手机版网址（**m.luffycity.com** ），会弹出手机版的路飞学城，点击 `我的`，登录自己的账号和密码，点击 `学习中心`，可以看到自己的课程，进行观看学习即可，如下图所示；

![phone01](https://hcdn1.luffycity.com/data/knight/tutor/phone01.png)

![phone02](https://hcdn1.luffycity.com/data/knight/tutor/phone02.jpg)



![phone03](https://hcdn1.luffycity.com/data/knight/tutor/phone03.png)



## <!--9. Changelog-->

<!--20180801 王翔 增加提现部分，增添部分微信通知图片-->

<!--20180802 王梅  新官网更新，增加了新的入学学位图片-->

<!--20180807 王梅  增加手机端登录路飞官网 观看视频 学习资料的通知-->
