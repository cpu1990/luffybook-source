### JQuery的筛选方法

前面咱们学习到了jquery的选择器的筛选用法，那么咱们接下来学习一下jquery的常用筛选方法，一张图搞定一切。

![](/jquery/jq筛选.png)



