## jquery内容补充

jquery除了咱们上面讲解的常用知识点之外，还有jquery 插件、jqueryUI知识点

jqueryUI 官网：

[https://jqueryui.com/](https://jqueryui.com/)

jqueryUI 中文网：

[http://www.jqueryui.org.cn/](http://www.jqueryui.org.cn/)

jquery插件内容包含：

![](/jquery/jquery_plugin.png)

官网demo：

[https://www.oschina.net/project/tag/273/jquery](https://www.oschina.net/project/tag/273/jquery)

里面包含了jquery插件效果和实现代码，大家可以好好的玩一下了！

