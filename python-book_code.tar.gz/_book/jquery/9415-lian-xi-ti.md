1.js的入口函数和jquery入口函数的区别？

2.jquery的值的操作哪个方法？

3.jquery和js对象如何转化？

4.阐述一下js和jquery的关系？

5.jquery的html属相操作是哪个方法？你认为是js中哪个方法封装来的？

6.列举jquery的文档操作的方法？以及他们的意思？

7.对一个元素显示隐藏分别使用类控制(addClass和removeClass)和文档操作(append())来实现,并描述一下他们的区别？

8.列举jquery的筛选方法有哪些？重点

9.jquery的事件有哪些？

10.mouseout和mouseover以及mouseenter和mouseleave的区别？

11.写jquery的ajax的get请求方法和post请求方法？
