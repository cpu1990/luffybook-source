## 1、Markdown介绍

markdown可以实现快速html文档编辑，格式优没，并且不需要使用html元素。  
markdown采用普通文本的形式，例如读书笔记等易于使用的文本格式进行编写。  
如果实在需要生成markdown不支持的html元素的话，可以直接在文本中嵌入h  
tml标签，markdown并不会将其显式出来。

## 2、标题标签

markdown使用\#方式对应生成相应的标题标签，\#的个数就是标题的题号！其中  
二号标题带添加下划线。markdown代码与效果图如下：

```
#标题1  
##标题2  
###标题3  
####标题4  
#####标题5  
######标题6  
#######标题7  
```

![](https://i.imgur.com/ug3cUFU.png)

## 3、引用文本

引用某段文本，效果是左侧有竖线进行修饰，每一行可以使用两个以上的**空格  
结尾**，就可以实现换行效果。markdown文本与效果如下：

> ```黄鹤楼~~~~~~~~~~
> 故人西辞黄鹤楼，烟花三月下扬州。  
> 孤帆远影碧空尽，唯见长江天际流。
>
> ~~~~~~~~~黄鹤楼
> ```
>
> 故人西辞黄鹤楼，烟花三月下扬州。  
> 孤帆远影碧空尽，唯见长江天际流。  
> ~~~~~~~~~

## 4、无编号列表

无符号列表是没有数字序号，使用圆点作为修饰符号。markdown使用\*、+、-效果  
是相同的。代码与效果如下：

* 条目1
* 条目2
* 条目3
* 条目4

* 条目1
* 条目2
* 条目3
* 条目4  

## 5、有编号列表

有序列表是有数字序号，markdown可以使用任何数字，不一定非要连续。但是生成的序号是连续的。markdown代码与效果如下：​  
    1. 条目1  
    1. 条目2  
    1. 条目3  
    1. 条目4

1. 条目1
2. 条目2
3. 条目3
4. 条目4

## 6、列表内使用标题、段落和引用

列表中可以使用标题，正常使用即可。列表内还可以嵌入段落。代码与效果如下：

* ### 条目1

  段落内容段，落内容段落内容段落内容段落内容段落内容段落内容。段落内容段落内容  
    段落内容段落内容段落内容段落内容段落内容段落内容段落内容段落内容段落内容。到  
    段落段落内容段落内容段落内容段落内容！

  ```java
  final V putVal(int hash, K key, V value, boolean onlyIfAbsent,
           boolean evict) {
  //...
  return null;
  }
  ```

* ### 条目2

  > 段落内容段落内容段落内容段落内容段落内容段落内容段落内容段落内容段落内容  
  > 段落内容段落内容段落内容段落内容内容内容内容内容内容内容段落内容段落内容  
  > 段落内容段落内容段落内容段落内容

* ### 条目1

  段落内容段，落内容段落内容段落内容段落内容段落内容段落内容。段落内容段落内容  
  段落内容段落内容段落内容段落内容段落内容段落内容段落内容段落内容段落内容。到  
  段落段落内容段落内容段落内容段落内容！

  ```
  final V putVal(int hash, K key, V value, boolean onlyIfAbsent,
                 boolean evict) {
      ...
      return null;
  }
  ```

* ### 条目2

  > 段落内容段落内容段落内容段落内容段落内容段落内容段落内容段落内容段落内容  
  > 段落内容段落内容段落内容段落内容内容内容内容内容内容内容段落内容段落内容  
  > 段落内容段落内容段落内容段落内容

## 7、分割线

markdown可以使用\*、-、\_实现分割线效果，三者区别是分割线和字体的效果不同。代码和效果如下：

```
部分1
----
部分2
***    
部分3
____
```

![](https://i.imgur.com/BZVbMDa.png)

## 8、文本强调

文本强调使用_或-线括起来。代码和效果如下：  
​  
    冬天的时候，_不要\*舔铁！！！

```
冬天的时候，**不要**舔铁！！！

冬天的时候，***不要***舔铁！！！
```

冬天的时候，_不要_舔铁！！！

冬天的时候，**不要**舔铁！！！

冬天的时候，_**不要**_舔铁！

## 9、表格

表格第一行使用\|分割多个字段的名称，就表示表头，第二行就是每列的对齐属性，:-表示左对齐、  
-：表示右对齐；:-:表示中间对齐。代码和效果如下：  
​  
\|  ID  \| 姓名       \|   年龄 \|  
\| :--: \| :------- \| ---: \|  
\|  1   \| tom      \|   90 \|  
\|  2   \| tomas    \|  100 \|  
\|  3   \| tomasLee \|   90 \|  
\|  4   \| tomson   \|   80 \|

## 10、时序图

时序图是UML图中非常重要的一种图，markdown中支持该图，但是markdownpad2软件不支持。代码效果如下：

    ​```sequence
        Alice->Bob: Hello Bob,how are you?
        note right of Bob: Bob thinks
        Bob-->Alice: I am good thanks!
    ​```

```sequence
    Alice->Bob: Hello Bob,how are you?
    note right of Bob: Bob thinks
    Bob-->Alice: I am good thanks!
```

![](https://i.imgur.com/1DTT96d.png)

## 11、流程图

流程图是UML图中非常重要的一种图，markdown中支持该图，但是markdownpad2软件不支持。代码效果如下：

    ​```flow
    st=>start: Start
    op=>operation: Your Operation
    cond=>condition: Yes or No?
    e=>end
    st->op->cond
    cond(yes)->e
    cond(no)->op
    </font>
    ​```

```flow
st=>start: Start
op=>operation: Your Operation
cond=>condition: Yes or No?
e=>end
st->op->cond
cond(yes)->e
cond(no)->op
</font>
```

![](https://i.imgur.com/ulJEgnG.png)

## 12、数学公式\(Latex\)

markdown可以使用latex语法完美支持数据公式，比如矩阵、微积分之类的。语法和效果如下：  
​

```shell
【常见符号】  
→        //趋近于,\to 
∞        //无穷大,\infty()

n         //求和,\sum\limits_{i=1}^{n}f(i) (∑i=1nf(i))
Σf(i)
i=1

x        //乘法,times(×)
÷        //除法，\div(÷)
±        //加减号，\pm
∘        //圆圈\circ
⋅        //点乘\cdot 

≤        //小于等于，\leq
≥        //大于等于\geq
⊂        //子集，\subset
⊃        //超集，\supset
∈        //在...中，\in

≠        //不等于\not=
≮        //不小于\not<
⊃        //̸不是超集，\not\supset

←        //左向箭头，\leftarrow
→        //右向箭头，\rightarrow(→)
⟶        //右向长箭头，\longrightarrow
↑        //上箭头，\uparrow
```

​    ∇        //？？？,\nabla

```shell
∠        //角度，\angle
∀        //任意，\forall
∃        //存在，\exists
′        //导数，\prime

sin        //\sinx
cos        //\cos
lim        //\lim
log        //\log
```

两点间距离公式:


$$
x = \dfrac{-b \pm \sqrt{b^2 - 4ac}}{2a}
$$


如图:

![](https://i.imgur.com/2t1krjd.png)

希腊字母表:

| 字母名称 | 大写 | markdown原文 | 小写 | markdown原文 |
| :---: | :---: | :---: | :---: | :---: |
| alpha | A | A | α | \alpha |
| beta | B | B | β | \beta |
| gamma | Γ | \Gamma | γ | \gamma |
| delta | Δ | \Delta | δ | \delta |
| epsilon | E | E | ϵ | \epsilon |
|  |  |  | ε | \varepsilon |
| zeta | Z | Z | ζ | \zeta |
| eta | E | E | η | \eta |
| theta | Θ | \Theta | θ | \theta |
| iota | I | I | ι | \iota |
| kappa | K | K | κ | \kappa |
| lambda | Λ | \Lambda | λ | \lambda |
| Mu | M | M | μ | \mu |
| nu | N | N | ν | \nu |
| xi | Ξ | \Xi | ξ | \xi |
| omicron | O | O | ο | \omicron |
| pi | Π | \Pi | π | \omicron |
| rho | P | P | ρ | \rho |
| sigma | Σ | \Sigma | σ | \sigma |
| tau | T | T | τ | \tau |
| upsilon | Υ | \Upsilon | υ | \upsilon |
| phi | Φ | \Phi | ϕ | \phi |
|  |  |  | φ | \varphi |
| chi | X | X | χ | \chi |
| psi | Ψ | \Psi | ψ | \ps |



