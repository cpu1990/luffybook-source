### 骑士计划目录

[【! 热】分校日记](http://book.luffycity.com/qsjh-book/diary/)
- [第一天](http://book.luffycity.com/qsjh-book/diary/chapter01.html)
- [第二天](http://book.luffycity.com/qsjh-book/diary/chapter02.html)
- [第四天](http://book.luffycity.com/qsjh-book/diary/chapter03.html)
- [第六天](http://book.luffycity.com/qsjh-book/diary/chapter04.html)
- [第八天](http://book.luffycity.com/qsjh-book/diary/chapter05.html)
- [有一种鸟，因为它的羽毛太过美丽，所以没有一个地方能关得住它](http://book.luffycity.com/qsjh-book/diary/chapter06.html)  
- [你要掌控自己的生活吗？](http://book.luffycity.com/qsjh-book/diary/chapter07.html)  
- [你是怎样通过学习改变命运的？](http://book.luffycity.com/qsjh-book/diary/chapter08.html)  
- [努力学习的意义到底在哪里？](http://book.luffycity.com/qsjh-book/diary/chapter09.html)  
- [today，大佬从北京来到了深圳](http://book.luffycity.com/qsjh-book/diary/chapter10.html)   
- [为何要把钱花在看不到的地方？](http://book.luffycity.com/qsjh-book/diary/chapter11.html)   
- [为了拯救传说中低情商的程序员，我们在一起干了这件事  ](http://book.luffycity.com/qsjh-book/diary/chapter12.html)   
- [偷偷告诉你，我们又给学员发福利啦](http://book.luffycity.com/qsjh-book/diary/chapter13.html)   
- [骑士计划PY二期班开班在即，猜猜我们最近在忙啥?](http://book.luffycity.com/qsjh-book/diary/chapter14.html)   
- 待续...


[为什么公司不愿意要培训机构出来的学生？](http://book.luffycity.com/qsjh-book/advertorial.html)

[骑士计划](http://book.luffycity.com/qsjh-book/knight/)
- [什么是骑士计划？](http://book.luffycity.com/qsjh-book/knight/chapter01.html)
- [有什么不同？](http://book.luffycity.com/qsjh-book/knight/chapter02.html)
- [如何参与骑士计划](http://book.luffycity.com/qsjh-book/knight/chapter03.html)
- [开设班型](http://book.luffycity.com/qsjh-book/knight/chapter04.html)
- [开班日期](http://book.luffycity.com/qsjh-book/knight/chapter05.html)

[实体班课程问题](http://book.luffycity.com/qsjh-book/question/)
- [能试听吗？](http://book.luffycity.com/qsjh-book/question/chapter01.html)
- [0基础可以学得会吗？](http://book.luffycity.com/qsjh-book/question/chapter02.html)
- [是否可以优惠？](http://book.luffycity.com/qsjh-book/question/chapter03.html)
- [学费可以分期吗？](http://book.luffycity.com/qsjh-book/question/chapter04.html)
- [是否可以重读？](http://book.luffycity.com/qsjh-book/question/chapter05.html)
- [包食宿吗？](http://book.luffycity.com/qsjh-book/question/chapter06.html)
- [是否有毕业证？](http://book.luffycity.com/qsjh-book/question/chapter07.html)
- [学不会可以退款吗？](http://book.luffycity.com/qsjh-book/question/chapter08.html)
- [上课时间怎么安排的？](http://book.luffycity.com/qsjh-book/question/chapter09.html)
- [学校地址在哪儿？](http://book.luffycity.com/qsjh-book/question/chapter10.html)

[周末班课程问题](http://book.luffycity.com/qsjh-book/wquestion/)

- [周末班和全日制班区别](http://book.luffycity.com/qsjh-book/wquestion/chapter01.html)
- [周末班学习周期多长](http://book.luffycity.com/qsjh-book/wquestion/chapter02.html)
- [开班日期](http://book.luffycity.com/qsjh-book/wquestion/chapter03.html)
- [开设班型](http://book.luffycity.com/qsjh-book/wquestion/chapter04.html)
- [周末班学习时间安排](http://book.luffycity.com/qsjh-book/wquestion/chapter05.html)
- [适应人群](http://book.luffycity.com/qsjh-book/wquestion/chapter06.html)


[讲师介绍](http://book.luffycity.com/qsjh-book/techers.html)

[【热】学员就业](http://book.luffycity.com/qsjh-book/jobs/)
- [【学员就业】Part01](http://book.luffycity.com/qsjh-book/jobs/chapter01.html)
- [【学员就业】Part02](http://book.luffycity.com/qsjh-book/jobs/chapter02.html)
- [【学员就业】Part03](http://book.luffycity.com/qsjh-book/jobs/chapter03.html)
- [【学员就业】Part04](http://book.luffycity.com/qsjh-book/jobs/chapter04.html)
- [【学员就业】Part05](http://book.luffycity.com/qsjh-book/jobs/chapter05.html)
- [【学员就业】Part06](http://book.luffycity.com/qsjh-book/jobs/chapter06.html)
- [【学员就业】Part07](http://book.luffycity.com/qsjh-book/jobs/chapter07.html)
- [【学员就业】Part08](http://book.luffycity.com/qsjh-book/jobs/chapter08.html)

[【必读】屌丝如何逆袭？](http://book.luffycity.com/qsjh-book/soul/)

- [哥们别逗了，写个脚本那真不叫运维自动化!](http://book.luffycity.com/qsjh-book/soul/chapter01.html)
- [普通运维人员就是秋后的蚂蚱！](http://book.luffycity.com/qsjh-book/soul/chapter02.html)
- [编程要自学或报班这事你都想不明白，那必然是你智商不够](http://book.luffycity.com/qsjh-book/soul/chapter03.html)
- [白领如何才能买得起Tesla电动车?](http://book.luffycity.com/qsjh-book/soul/chapter04.html)
- [关于认识、格局、多维度发展的感触](http://book.luffycity.com/qsjh-book/soul/chapter05.html)
- [给一位做技术迷茫的同学回信](http://book.luffycity.com/qsjh-book/soul/chapter06.html)
- [不敢想](http://book.luffycity.com/qsjh-book/soul/chapter07.html)

[师兄分享](http://book.luffycity.com/qsjh-book/bro/)
- [【学员分享】我的学习之路](http://book.luffycity.com/qsjh-book/bro/chapter01.html)
- [【学员分享】学习碎碎念](http://book.luffycity.com/qsjh-book/bro/chapter02.html)
- [【学员分享】31岁印刷厂美工转型Linux](http://book.luffycity.com/qsjh-book/bro/chapter03.html)

[联系我们](http://book.luffycity.com/qsjh-book/contact.html)

<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?5acb80dbfab84cdf5a7d41a8b3581049";
  var s = document.getElementsByTagName("script")[0];
  s.parentNode.insertBefore(hm, s);
})();
</script>
